package com.goerner.bilderzupdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class EditableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var bitmap: Bitmap? = null
        set(value) {
            field = value
            requestLayout()
            invalidate()
        }

    var lines: List<TextLine> = emptyList()
    var onLineTapped: ((TextLine) -> Unit)? = null
    var addTextMode = false
    var onEmptyTapped: ((Int, Int) -> Unit)? = null

    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    private val debugPaint = Paint().apply {
        color = 0x330000FF
        style = Paint.Style.FILL
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val bmp = bitmap
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = if (bmp != null) {
            (width.toFloat() * bmp.height / bmp.width).toInt()
        } else {
            MeasureSpec.getSize(heightMeasureSpec)
        }
        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap ?: return

        scale = width.toFloat() / bmp.width
        offsetX = 0f
        offsetY = 0f

        canvas.save()
        canvas.scale(scale, scale)
        canvas.drawBitmap(bmp, 0f, 0f, null)

        for (line in lines) {
            canvas.drawRect(line.rect, debugPaint)
        }
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val bmpX = (event.x - offsetX) / scale
            val bmpY = (event.y - offsetY) / scale

            if (addTextMode) {
                onEmptyTapped?.invoke(bmpX.toInt(), bmpY.toInt())
                return true
            }

            val hit = lines.firstOrNull { it.rect.contains(bmpX.toInt(), bmpY.toInt()) }
            if (hit != null) {
                onLineTapped?.invoke(hit)
                return true
            }
        }
        return true
    }
}

data class TextLine(val text: String, val rect: Rect)
