package com.goerner.bilderzupdf

/**
 * PDF-Seitengrößen werden in Punkten gemessen (72 pro Zoll), nicht in Pixeln.
 * Ohne Umrechnung wird ein Foto mit z.B. 3000x4000 Pixeln als 3000x4000 Punkte
 * große PDF-Seite gespeichert - das ist um ein Vielfaches größer als eine normale
 * Seite und wirkt bei 100% Zoom riesig. Diese Funktion rechnet Pixel bei einer
 * angenommenen Auflösung (Standard: 150 dpi, ein für Dokumente üblicher Wert)
 * auf eine normal große PDF-Seite in Punkten um.
 */
fun pixelsToPdfPoints(widthPx: Int, heightPx: Int, assumedDpi: Float = 150f): Pair<Float, Float> {
    val widthPt = widthPx * 72f / assumedDpi
    val heightPt = heightPx * 72f / assumedDpi
    return Pair(widthPt, heightPt)
}

/**
 * Android's PdfDocument speichert Bitmaps unkomprimiert/verlustfrei, was bei Fotos
 * zu riesigen PDF-Dateien führt (mehrere MB pro Seite). Durch einen JPEG-Umweg
 * (komprimieren + wieder dekodieren) vor dem Einfügen wird das Bild so vorbereitet,
 * dass die finale PDF-Datei um ein Vielfaches kleiner wird, ohne sichtbaren
 * Qualitätsverlust bei normaler Betrachtung.
 */
fun compressBitmapForPdf(bitmap: android.graphics.Bitmap, quality: Int = 92): android.graphics.Bitmap {
    val stream = java.io.ByteArrayOutputStream()
    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, stream)
    val bytes = stream.toByteArray()
    return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: bitmap
}
