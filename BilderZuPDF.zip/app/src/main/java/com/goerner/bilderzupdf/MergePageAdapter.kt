package com.goerner.bilderzupdf

import android.graphics.Matrix
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ItemPdfPageBinding

class MergePageAdapter(
    private val items: MutableList<MergePage>,
    private val onRemove: (Int) -> Unit,
    private val onEdit: (Int) -> Unit
) : RecyclerView.Adapter<MergePageAdapter.PageViewHolder>() {

    inner class PageViewHolder(val binding: ItemPdfPageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val binding = ItemPdfPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        val page = items[position]

        val matrix = Matrix()
        matrix.postRotate(page.rotationDegrees.toFloat())
        val rotated = android.graphics.Bitmap.createBitmap(
            page.bitmap, 0, 0, page.bitmap.width, page.bitmap.height, matrix, true
        )
        holder.binding.imgPageThumb.setImageBitmap(rotated)
        holder.binding.txtSourceName.text = page.sourceName

        holder.binding.btnRotateLeft.setOnClickListener {
            page.rotationDegrees = (page.rotationDegrees - 90 + 360) % 360
            notifyItemChanged(holder.bindingAdapterPosition)
        }
        holder.binding.btnRotateRight.setOnClickListener {
            page.rotationDegrees = (page.rotationDegrees + 90) % 360
            notifyItemChanged(holder.bindingAdapterPosition)
        }
        holder.binding.btnRemovePage.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onRemove(pos)
        }
        holder.binding.btnEditPage.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onEdit(pos)
        }
    }

    override fun getItemCount(): Int = items.size

    fun moveItem(from: Int, to: Int) {
        val item = items.removeAt(from)
        items.add(to, item)
        notifyItemMoved(from, to)
    }
}
