package com.goerner.bilderzupdf

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val selectedImages = mutableListOf<Uri>()
    private lateinit var adapter: ImageAdapter

    private val pickImagesLauncher =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) {
                selectedImages.addAll(uris)
                adapter.notifyDataSetChanged()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = ImageAdapter(selectedImages) { position ->
            selectedImages.removeAt(position)
            adapter.notifyItemRemoved(position)
        }
        binding.recyclerImages.layoutManager = LinearLayoutManager(this)
        binding.recyclerImages.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                val item = selectedImages.removeAt(from)
                selectedImages.add(to, item)
                adapter.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.recyclerImages)

        binding.btnPickImages.setOnClickListener {
            pickImagesLauncher.launch("image/*")
        }

        binding.btnShowPdfs.setOnClickListener {
            startActivity(android.content.Intent(this, PdfListActivity::class.java))
        }

        binding.btnCreatePdf.setOnClickListener {
            createPdf()
        }
    }

    private fun createPdf() {
        if (selectedImages.isEmpty()) {
            Toast.makeText(this, "Bitte zuerst Bilder auswählen", Toast.LENGTH_SHORT).show()
            return
        }

        val pdfDir = File(filesDir, "pdfs")
        if (!pdfDir.exists()) pdfDir.mkdirs()

        val customName = binding.editPdfName.text.toString().trim()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = if (customName.isNotEmpty()) "${customName}_$timestamp.pdf" else "PDF_$timestamp.pdf"
        val outFile = File(pdfDir, fileName)

        val document = PdfDocument()

        try {
            for (uri in selectedImages) {
                val bitmap = loadBitmap(uri) ?: continue
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, document.pages.size + 1).create()
                val page = document.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                document.finishPage(page)
                bitmap.recycle()
            }

            FileOutputStream(outFile).use { out ->
                document.writeTo(out)
            }
            Toast.makeText(this, "PDF erstellt: $fileName", Toast.LENGTH_LONG).show()

            selectedImages.clear()
            adapter.notifyDataSetChanged()
            binding.editPdfName.setText("")
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler beim Erstellen der PDF: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            document.close()
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bitmap = BitmapFactory.decodeStream(input)
                val rotated = rotateIfNeeded(uri, bitmap)
                rotated
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun rotateIfNeeded(uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                val exif = androidx.exifinterface.media.ExifInterface(input)
                val orientation = exif.getAttributeInt(
                    androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                )
                val matrix = Matrix()
                when (orientation) {
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    else -> return bitmap
                }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            } ?: bitmap
        } catch (e: Exception) {
            bitmap
        }
    }
}
