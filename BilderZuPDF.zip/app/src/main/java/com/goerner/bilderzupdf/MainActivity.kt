package com.goerner.bilderzupdf

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val selectedImages = mutableListOf<Uri>()
    private lateinit var adapter: ImageAdapter
    private var editingPosition: Int = -1

    private val pickImagesLauncher =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) {
                selectedImages.addAll(uris)
                adapter.notifyDataSetChanged()
            }
        }

    private val editImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val path = result.data?.getStringExtra(ImageEditActivity.EXTRA_RESULT_PATH)
            if (result.resultCode == RESULT_OK && path != null && editingPosition >= 0) {
                selectedImages[editingPosition] = Uri.fromFile(File(path))
                adapter.notifyItemChanged(editingPosition)
            }
            editingPosition = -1
        }

    private val pickPdfLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val intent = Intent(this, PdfEditActivity::class.java)
                intent.putExtra(PdfEditActivity.EXTRA_PDF_URI, uri.toString())
                startActivity(intent)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = ImageAdapter(
            selectedImages,
            onRemove = { position ->
                selectedImages.removeAt(position)
                adapter.notifyItemRemoved(position)
            },
            onEdit = { position ->
                editingPosition = position
                val intent = Intent(this, ImageEditActivity::class.java)
                intent.putExtra(ImageEditActivity.EXTRA_IMAGE_URI, selectedImages[position].toString())
                editImageLauncher.launch(intent)
            }
        )
        binding.recyclerImages.layoutManager = LinearLayoutManager(this)
        binding.recyclerImages.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                val item = selectedImages.removeAt(from)
                selectedImages.add(to, item)
                adapter.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.recyclerImages)

        binding.btnPickImages.setOnClickListener {
            pickImagesLauncher.launch("image/*")
        }

        binding.btnShowPdfs.setOnClickListener {
            startActivity(Intent(this, PdfListActivity::class.java))
        }

        binding.btnEditExistingPdf.setOnClickListener {
            pickPdfLauncher.launch("application/pdf")
        }

        binding.btnMergePdfs.setOnClickListener {
            startActivity(Intent(this, PdfMergeActivity::class.java))
        }

        binding.btnCreatePdf.setOnClickListener {
            createPdf()
        }
    }

    private fun createPdf() {
        if (selectedImages.isEmpty()) {
            Toast.makeText(this, "Bitte zuerst Bilder auswählen", Toast.LENGTH_SHORT).show()
            return
        }

        val customName = binding.editPdfName.text.toString().trim()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = if (customName.isNotEmpty()) "${customName}_$timestamp.pdf" else "PDF_$timestamp.pdf"

        val document = PdfDocument()

        try {
            for (uri in selectedImages) {
                val bitmap = loadBitmap(uri) ?: continue
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, document.pages.size + 1).create()
                val page = document.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                document.finishPage(page)
                bitmap.recycle()
            }

            val savedUri = savePdfToDownloads(fileName, document)

            if (savedUri != null) {
                Toast.makeText(this, "PDF gespeichert in Downloads: $fileName", Toast.LENGTH_LONG).show()
                selectedImages.clear()
                adapter.notifyDataSetChanged()
                binding.editPdfName.setText("")
            } else {
                Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler beim Erstellen der PDF: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            document.close()
        }
    }

    private fun savePdfToDownloads(fileName: String, document: PdfDocument): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BilderZuPDF")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { out -> document.writeTo(out) }
            uri
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appDir = File(downloadsDir, "BilderZuPDF")
            if (!appDir.exists()) appDir.mkdirs()
            val outFile = File(appDir, fileName)
            java.io.FileOutputStream(outFile).use { out -> document.writeTo(out) }
            Uri.fromFile(outFile)
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                val bitmap = BitmapFactory.decodeStream(input)
                rotateIfNeeded(uri, bitmap)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun rotateIfNeeded(uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                val exif = androidx.exifinterface.media.ExifInterface(input)
                val orientation = exif.getAttributeInt(
                    androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                )
                val matrix = Matrix()
                when (orientation) {
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    else -> return bitmap
                }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            } ?: bitmap
        } catch (e: Exception) {
            bitmap
        }
    }
}
