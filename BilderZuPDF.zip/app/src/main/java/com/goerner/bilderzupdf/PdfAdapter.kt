package com.goerner.bilderzupdf

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ItemPdfBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfAdapter(
    private val items: MutableList<PdfEntry>,
    private val onShare: (PdfEntry) -> Unit,
    private val onDelete: (PdfEntry) -> Unit,
    private val onOpen: (PdfEntry) -> Unit
) : RecyclerView.Adapter<PdfAdapter.PdfViewHolder>() {

    inner class PdfViewHolder(val binding: ItemPdfBinding) : RecyclerView.ViewHolder(binding.root)

    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PdfViewHolder {
        val binding = ItemPdfBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PdfViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PdfViewHolder, position: Int) {
        val entry = items[position]
        holder.binding.txtPdfName.text = entry.name
        val sizeKb = entry.size / 1024
        holder.binding.txtPdfInfo.text = "${dateFormat.format(Date(entry.lastModified))} · $sizeKb KB"

        holder.binding.root.setOnClickListener { onOpen(entry) }
        holder.binding.btnShare.setOnClickListener { onShare(entry) }
        holder.binding.btnDelete.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            onDelete(entry)
            items.removeAt(pos)
            notifyItemRemoved(pos)
        }
    }

    override fun getItemCount(): Int = items.size
}
