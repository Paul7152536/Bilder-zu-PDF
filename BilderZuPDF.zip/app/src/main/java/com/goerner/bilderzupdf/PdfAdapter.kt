package com.goerner.bilderzupdf

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ItemPdfBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfAdapter(
    private val items: MutableList<File>,
    private val onShare: (File) -> Unit,
    private val onDelete: (File) -> Unit,
    private val onOpen: (File) -> Unit
) : RecyclerView.Adapter<PdfAdapter.PdfViewHolder>() {

    inner class PdfViewHolder(val binding: ItemPdfBinding) : RecyclerView.ViewHolder(binding.root)

    private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PdfViewHolder {
        val binding = ItemPdfBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PdfViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PdfViewHolder, position: Int) {
        val file = items[position]
        holder.binding.txtPdfName.text = file.name
        val sizeKb = file.length() / 1024
        holder.binding.txtPdfInfo.text = "${dateFormat.format(Date(file.lastModified()))} · $sizeKb KB"

        holder.binding.root.setOnClickListener { onOpen(file) }
        holder.binding.btnShare.setOnClickListener { onShare(file) }
        holder.binding.btnDelete.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            onDelete(file)
            items.removeAt(pos)
            notifyItemRemoved(pos)
        }
    }

    override fun getItemCount(): Int = items.size
}
