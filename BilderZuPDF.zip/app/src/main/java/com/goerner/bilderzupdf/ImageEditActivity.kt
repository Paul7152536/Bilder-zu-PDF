package com.goerner.bilderzupdf

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.goerner.bilderzupdf.databinding.ActivityImageEditBinding
import java.io.File
import java.io.FileOutputStream

class ImageEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImageEditBinding
    private var workingBitmap: Bitmap? = null
    private var hasChanges = false

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_RESULT_PATH = "extra_result_path"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finishWithoutSaving() }

        val uriString = intent.getStringExtra(EXTRA_IMAGE_URI)
        if (uriString == null) {
            finish()
            return
        }
        val uri = Uri.parse(uriString)

        loadBitmapAndRecognize(uri)

        binding.btnDone.setOnClickListener {
            saveAndReturn()
        }
    }

    private fun loadBitmapAndRecognize(uri: Uri) {
        val original = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (original == null) {
            Toast.makeText(this, "Bild konnte nicht geladen werden", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        workingBitmap = original.copy(Bitmap.Config.ARGB_8888, true)
        binding.editableImageView.bitmap = workingBitmap
        runTextRecognition()
    }

    private fun runTextRecognition() {
        val bmp = workingBitmap ?: return
        binding.txtStatus.text = "Erkenne Text..."

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bmp, 0)

        recognizer.process(image)
            .addOnSuccessListener { result ->
                val lines = mutableListOf<TextLine>()
                for (block in result.textBlocks) {
                    for (line in block.lines) {
                        val box = line.boundingBox ?: continue
                        lines.add(TextLine(line.text, box))
                    }
                }
                binding.editableImageView.lines = lines
                binding.editableImageView.onLineTapped = { line -> showEditDialog(line) }
                binding.editableImageView.invalidate()
                binding.txtStatus.text = if (lines.isEmpty())
                    "Kein Text erkannt"
                else
                    "${lines.size} Textzeilen erkannt – antippen zum Bearbeiten"
            }
            .addOnFailureListener { e ->
                binding.txtStatus.text = "Texterkennung fehlgeschlagen: ${e.message}"
            }
    }

    private fun showEditDialog(line: TextLine) {
        val input = EditText(this)
        input.setText(line.text)

        AlertDialog.Builder(this)
            .setTitle("Text bearbeiten")
            .setView(input)
            .setPositiveButton("Übernehmen") { _, _ ->
                applyTextChange(line, input.text.toString())
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun applyTextChange(line: TextLine, newText: String) {
        val bmp = workingBitmap ?: return
        val canvas = Canvas(bmp)
        val rect = line.rect

        // Hintergrundfarbe knapp über der Zeile abgreifen (meist Papierhintergrund, kein Text)
        val sampleY = (rect.top - 3).coerceAtLeast(0)
        val sampleX = ((rect.left + rect.right) / 2).coerceIn(0, bmp.width - 1)
        val bgColor = bmp.getPixel(sampleX, sampleY.coerceAtMost(bmp.height - 1))

        val pad = (rect.height() * 0.15f).coerceAtLeast(2f)
        val fillPaint = Paint().apply { color = bgColor }
        canvas.drawRect(
            rect.left - pad, rect.top - pad,
            rect.right + pad, rect.bottom + pad,
            fillPaint
        )

        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = rect.height() * 0.85f
        }
        val textY = rect.bottom - (rect.height() - textPaint.textSize) / 2
        canvas.drawText(newText, rect.left.toFloat(), textY, textPaint)

        hasChanges = true

        // Zeile in der Liste aktualisieren, damit erneutes Antippen den neuen Text zeigt
        val updatedLines = binding.editableImageView.lines.map {
            if (it === line) TextLine(newText, it.rect) else it
        }
        binding.editableImageView.lines = updatedLines
        binding.editableImageView.invalidate()
    }

    private fun saveAndReturn() {
        val bmp = workingBitmap
        if (bmp == null || !hasChanges) {
            finishWithoutSaving()
            return
        }
        val outFile = File(cacheDir, "edited_${System.currentTimeMillis()}.png")
        FileOutputStream(outFile).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        val resultIntent = android.content.Intent()
        resultIntent.putExtra(EXTRA_RESULT_PATH, outFile.absolutePath)
        setResult(RESULT_OK, resultIntent)
        finish()
    }

    private fun finishWithoutSaving() {
        setResult(RESULT_CANCELED)
        finish()
    }
}
