package com.goerner.bilderzupdf

import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.goerner.bilderzupdf.databinding.ActivityPdfEditBinding
import java.io.File

class PdfEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfEditBinding
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var pageBitmaps = mutableMapOf<Int, Bitmap>()
    private var pageLines = mutableMapOf<Int, MutableList<TextLine>>()
    private var currentPage = 0
    private var pageCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val uriString = intent.getStringExtra(EXTRA_PDF_URI)
        if (uriString == null) {
            finish()
            return
        }
        openPdf(Uri.parse(uriString))

        binding.btnPrevPage.setOnClickListener { if (currentPage > 0) showPage(currentPage - 1) }
        binding.btnNextPage.setOnClickListener { if (currentPage < pageCount - 1) showPage(currentPage + 1) }
        binding.btnAddTextMode.setOnClickListener {
            val newState = !binding.editableImageView.addTextMode
            binding.editableImageView.addTextMode = newState
            binding.btnAddTextMode.text = if (newState)
                "Modus aktiv: Auf die Stelle tippen, wo Text hin soll"
            else
                "+ Text hinzufügen (Modus an/aus)"
        }
        binding.editableImageView.onEmptyTapped = { x, y -> showAddTextDialog(x, y) }
        binding.btnSavePdf.setOnClickListener { savePdf() }
    }

    private fun openPdf(uri: Uri) {
        try {
            val fd = contentResolver.openFileDescriptor(uri, "r") ?: run {
                Toast.makeText(this, "PDF konnte nicht geöffnet werden", Toast.LENGTH_LONG).show()
                finish(); return
            }
            pfd = fd
            renderer = PdfRenderer(fd)
            pageCount = renderer!!.pageCount
            showPage(0)
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler beim Öffnen: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun showPage(index: Int) {
        currentPage = index
        binding.txtPageIndicator.text = "Seite ${index + 1} / $pageCount"
        binding.btnPrevPage.isEnabled = index > 0
        binding.btnNextPage.isEnabled = index < pageCount - 1

        val bmp = pageBitmaps.getOrPut(index) { renderPageToBitmap(index) }
        binding.editableImageView.bitmap = bmp

        val lines = pageLines[index]
        if (lines == null) {
            binding.editableImageView.lines = emptyList()
            runOcrOnPage(index, bmp)
        } else {
            binding.editableImageView.lines = lines
            binding.txtStatus.text = "${lines.size} Textzeilen erkannt – antippen zum Bearbeiten"
        }
        binding.editableImageView.onLineTapped = { line -> showEditDialog(line) }
        binding.editableImageView.invalidate()
    }

    private fun renderPageToBitmap(index: Int): Bitmap {
        val page = renderer!!.openPage(index)
        val scale = 2
        val bmp = Bitmap.createBitmap(page.width * scale, page.height * scale, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        return bmp
    }

    private fun runOcrOnPage(index: Int, bmp: Bitmap) {
        binding.txtStatus.text = "Erkenne Text..."
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bmp, 0)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val lines = mutableListOf<TextLine>()
                for (block in result.textBlocks) {
                    for (line in block.lines) {
                        val box = line.boundingBox ?: continue
                        lines.add(TextLine(line.text, box))
                    }
                }
                pageLines[index] = lines
                if (index == currentPage) {
                    binding.editableImageView.lines = lines
                    binding.editableImageView.invalidate()
                    binding.txtStatus.text = if (lines.isEmpty())
                        "Kein Text erkannt"
                    else
                        "${lines.size} Textzeilen erkannt – antippen zum Bearbeiten"
                }
            }
            .addOnFailureListener { e ->
                if (index == currentPage) binding.txtStatus.text = "Texterkennung fehlgeschlagen: ${e.message}"
            }
    }

    private fun showEditDialog(line: TextLine) {
        val input = EditText(this)
        input.setText(line.text)
        AlertDialog.Builder(this)
            .setTitle("Text bearbeiten")
            .setView(input)
            .setPositiveButton("Übernehmen") { _, _ -> applyTextChange(line, input.text.toString()) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun applyTextChange(line: TextLine, newText: String) {
        val bmp = pageBitmaps[currentPage] ?: return
        val canvas = Canvas(bmp)
        val rect = line.rect

        val sampleY = (rect.top - 3).coerceAtLeast(0)
        val sampleX = ((rect.left + rect.right) / 2).coerceIn(0, bmp.width - 1)
        val bgColor = bmp.getPixel(sampleX, sampleY.coerceAtMost(bmp.height - 1))

        val pad = (rect.height() * 0.15f).coerceAtLeast(2f)
        canvas.drawRect(
            rect.left - pad, rect.top - pad, rect.right + pad, rect.bottom + pad,
            Paint().apply { color = bgColor }
        )

        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = rect.height() * 0.85f
        }
        val textY = rect.bottom - (rect.height() - textPaint.textSize) / 2
        canvas.drawText(newText, rect.left.toFloat(), textY, textPaint)

        val updated = pageLines[currentPage]?.map {
            if (it === line) TextLine(newText, it.rect) else it
        }?.toMutableList() ?: mutableListOf()
        pageLines[currentPage] = updated
        binding.editableImageView.lines = updated
        binding.editableImageView.invalidate()
    }

    private fun showAddTextDialog(x: Int, y: Int) {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Text einfügen")
            .setView(input)
            .setPositiveButton("Einfügen") { _, _ -> addNewText(x, y, input.text.toString()) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun addNewText(x: Int, y: Int, text: String) {
        if (text.isBlank()) return
        val bmp = pageBitmaps[currentPage] ?: return
        val canvas = Canvas(bmp)

        val textPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = bmp.height * 0.025f
        }
        canvas.drawText(text, x.toFloat(), y.toFloat(), textPaint)

        val bounds = android.graphics.Rect()
        textPaint.getTextBounds(text, 0, text.length, bounds)
        val rect = android.graphics.Rect(x, y - bounds.height(), x + bounds.width(), y)
        val updated = (pageLines[currentPage] ?: mutableListOf()).also { it.add(TextLine(text, rect)) }
        pageLines[currentPage] = updated
        binding.editableImageView.lines = updated

        binding.editableImageView.addTextMode = false
        binding.btnAddTextMode.text = "+ Text hinzufügen (Modus an/aus)"
        binding.editableImageView.invalidate()
    }

    private fun savePdf() {
        val total = pageCount
        if (total == 0) return

        val document = PdfDocument()
        try {
            for (i in 0 until total) {
                val bmp = pageBitmaps.getOrPut(i) { renderPageToBitmap(i) }
                val pageInfo = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, i + 1).create()
                val page = document.startPage(pageInfo)
                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                document.finishPage(page)
            }

            val fileName = "Bearbeitet_${System.currentTimeMillis()}.pdf"
            val uri = saveToDownloads(fileName, document)
            if (uri != null) {
                Toast.makeText(this, "Gespeichert in Downloads: $fileName", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            document.close()
        }
    }

    private fun saveToDownloads(fileName: String, document: PdfDocument): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BilderZuPDF")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
            uri
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appDir = File(downloadsDir, "BilderZuPDF")
            if (!appDir.exists()) appDir.mkdirs()
            val outFile = File(appDir, fileName)
            java.io.FileOutputStream(outFile).use { document.writeTo(it) }
            Uri.fromFile(outFile)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        renderer?.close()
        pfd?.close()
    }

    companion object {
        const val EXTRA_PDF_URI = "extra_pdf_uri"
    }
}
