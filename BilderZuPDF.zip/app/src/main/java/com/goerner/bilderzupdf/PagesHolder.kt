package com.goerner.bilderzupdf

/**
 * Einfacher In-Memory-Zwischenspeicher, um die aktuelle Seitenliste
 * zwischen PdfMergeActivity und PdfPreviewActivity zu teilen,
 * ohne große Bitmaps durch Intents schicken zu müssen.
 */
object PagesHolder {
    var pages: MutableList<MergePage> = mutableListOf()
}
