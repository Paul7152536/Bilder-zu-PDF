package com.goerner.bilderzupdf

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.goerner.bilderzupdf.databinding.ActivityPdfPreviewBinding
import java.io.File

class PdfPreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.recyclerPreview.layoutManager = LinearLayoutManager(this)
        binding.recyclerPreview.adapter = PreviewPageAdapter(PagesHolder.pages)

        binding.btnDownloadFinal.setOnClickListener { saveFinalPdf() }
    }

    private fun saveFinalPdf() {
        val pages = PagesHolder.pages
        if (pages.isEmpty()) return

        val document = PdfDocument()
        try {
            for (mergePage in pages) {
                val rotated = if (mergePage.rotationDegrees != 0) {
                    val matrix = Matrix()
                    matrix.postRotate(mergePage.rotationDegrees.toFloat())
                    Bitmap.createBitmap(
                        mergePage.bitmap, 0, 0,
                        mergePage.bitmap.width, mergePage.bitmap.height,
                        matrix, true
                    )
                } else {
                    mergePage.bitmap
                }

                val pageInfo = PdfDocument.PageInfo.Builder(rotated.width, rotated.height, document.pages.size + 1).create()
                val pdfPage = document.startPage(pageInfo)
                pdfPage.canvas.drawBitmap(rotated, 0f, 0f, null)
                document.finishPage(pdfPage)
            }

            val fileName = "PDF_${System.currentTimeMillis()}.pdf"
            val uri = saveToDownloads(fileName, document)
            if (uri != null) {
                Toast.makeText(this, "Gespeichert in Downloads: $fileName", Toast.LENGTH_LONG).show()
                setResult(RESULT_OK)
                finish()
            } else {
                Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            document.close()
        }
    }

    private fun saveToDownloads(fileName: String, document: PdfDocument): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BilderZuPDF")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
            uri
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val appDir = File(downloadsDir, "BilderZuPDF")
            if (!appDir.exists()) appDir.mkdirs()
            val outFile = File(appDir, fileName)
            java.io.FileOutputStream(outFile).use { document.writeTo(it) }
            Uri.fromFile(outFile)
        }
    }
}
