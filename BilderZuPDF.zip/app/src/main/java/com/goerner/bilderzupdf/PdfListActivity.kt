package com.goerner.bilderzupdf

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.goerner.bilderzupdf.databinding.ActivityPdfListBinding
import java.io.File

class PdfListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.recyclerPdfs.layoutManager = LinearLayoutManager(this)
        loadPdfs()
    }

    private fun loadPdfs() {
        val pdfDir = File(filesDir, "pdfs")
        val files = pdfDir.listFiles()?.sortedByDescending { it.lastModified() }?.toMutableList()
            ?: mutableListOf()

        binding.recyclerPdfs.adapter = PdfAdapter(
            files,
            onShare = { file -> sharePdf(file) },
            onDelete = { file ->
                file.delete()
                loadPdfs()
            },
            onOpen = { file -> openPdf(file) }
        )
    }

    private fun getUriForFile(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private fun sharePdf(file: File) {
        val uri = getUriForFile(file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "PDF teilen"))
    }

    private fun openPdf(file: File) {
        val uri = getUriForFile(file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "PDF öffnen"))
    }
}
