package com.goerner.bilderzupdf

import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.goerner.bilderzupdf.databinding.ActivityPdfListBinding
import java.io.File

data class PdfEntry(val uri: Uri, val name: String, val size: Long, val lastModified: Long)

class PdfListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.recyclerPdfs.layoutManager = LinearLayoutManager(this)
        loadPdfs()
    }

    private fun loadPdfs() {
        val entries = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            loadFromMediaStore()
        } else {
            loadFromFileSystem()
        }.sortedByDescending { it.lastModified }.toMutableList()

        binding.recyclerPdfs.adapter = PdfAdapter(
            entries,
            onShare = { entry -> sharePdf(entry) },
            onDelete = { entry -> deletePdf(entry) },
            onOpen = { entry -> openPdf(entry) }
        )
    }

    private fun loadFromMediaStore(): List<PdfEntry> {
        val list = mutableListOf<PdfEntry>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.RELATIVE_PATH
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
        val selectionArgs = arrayOf("%BilderZuPDF%")

        contentResolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            projection, selection, selectionArgs, null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                list.add(
                    PdfEntry(
                        uri = uri,
                        name = cursor.getString(nameCol),
                        size = cursor.getLong(sizeCol),
                        lastModified = cursor.getLong(dateCol) * 1000
                    )
                )
            }
        }
        return list
    }

    private fun loadFromFileSystem(): List<PdfEntry> {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val appDir = File(downloadsDir, "BilderZuPDF")
        val files = appDir.listFiles { f -> f.extension.equals("pdf", ignoreCase = true) } ?: emptyArray()
        return files.map { PdfEntry(Uri.fromFile(it), it.name, it.length(), it.lastModified()) }
    }

    private fun sharePdf(entry: PdfEntry) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, entry.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "PDF teilen"))
    }

    private fun openPdf(entry: PdfEntry) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(entry.uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "PDF öffnen"))
    }

    private fun deletePdf(entry: PdfEntry) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentResolver.delete(entry.uri, null, null)
            } else {
                entry.uri.path?.let { File(it).delete() }
            }
        } catch (e: Exception) {
        }
        loadPdfs()
    }
}
