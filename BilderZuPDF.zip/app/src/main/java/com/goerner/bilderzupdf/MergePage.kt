package com.goerner.bilderzupdf

import android.graphics.Bitmap

data class MergePage(
    val id: Int,
    val bitmap: Bitmap,
    var rotationDegrees: Int = 0,
    val sourceName: String
)
