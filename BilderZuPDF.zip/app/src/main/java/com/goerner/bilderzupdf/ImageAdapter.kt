package com.goerner.bilderzupdf

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ItemImageBinding

class ImageAdapter(
    private val items: MutableList<Uri>,
    private val onRemove: (Int) -> Unit,
    private val onEdit: (Int) -> Unit
) : RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    inner class ImageViewHolder(val binding: ItemImageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val binding = ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ImageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val uri = items[position]
        holder.binding.imgThumb.setImageURI(uri)
        holder.binding.txtName.text = "Bild ${position + 1}"
        holder.binding.btnRemove.setOnClickListener {
            onRemove(holder.bindingAdapterPosition)
        }
        holder.binding.btnEditText.setOnClickListener {
            onEdit(holder.bindingAdapterPosition)
        }
    }

    override fun getItemCount(): Int = items.size
}
