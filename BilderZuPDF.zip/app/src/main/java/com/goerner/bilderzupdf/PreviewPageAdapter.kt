package com.goerner.bilderzupdf

import android.graphics.Matrix
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ItemPreviewPageBinding

class PreviewPageAdapter(private val items: List<MergePage>) :
    RecyclerView.Adapter<PreviewPageAdapter.PreviewViewHolder>() {

    inner class PreviewViewHolder(val binding: ItemPreviewPageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PreviewViewHolder {
        val binding = ItemPreviewPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PreviewViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PreviewViewHolder, position: Int) {
        val page = items[position]
        val matrix = Matrix()
        matrix.postRotate(page.rotationDegrees.toFloat())
        val rotated = android.graphics.Bitmap.createBitmap(
            page.bitmap, 0, 0, page.bitmap.width, page.bitmap.height, matrix, true
        )
        holder.binding.imgPreviewThumb.setImageBitmap(rotated)
        holder.binding.txtPreviewLabel.text = "Seite ${position + 1} von ${items.size}"
    }

    override fun getItemCount(): Int = items.size
}
