package com.goerner.bilderzupdf

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.goerner.bilderzupdf.databinding.ActivityPdfCompressBinding
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.roundToInt

class PdfCompressActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfCompressBinding
    private var pickedUri: Uri? = null
    private var originalSizeBytes: Long = 0
    private var compressedBytes: ByteArray? = null
    private var originalFileName: String = "PDF"

    private val pickPdfLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) onPdfPicked(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfCompressBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnPickPdf.setOnClickListener { pickPdfLauncher.launch("application/pdf") }

        binding.seekQuality.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.txtQualityLabel.text = "Qualität: ${qualityFromProgress(progress)}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnRunCompress.setOnClickListener { runCompression() }
        binding.btnSaveCompressed.setOnClickListener { saveCompressed() }
    }

    private fun qualityFromProgress(progress: Int): Int = progress + 30

    private fun onPdfPicked(uri: Uri) {
        pickedUri = uri
        originalFileName = getFileName(uri)
        originalSizeBytes = getFileSize(uri)
        binding.txtOriginalSize.text = "Originalgröße: ${formatSize(originalSizeBytes)}"
        binding.qualityGroup.visibility = android.view.View.VISIBLE
        binding.txtResult.visibility = android.view.View.GONE
        binding.btnSaveCompressed.visibility = android.view.View.GONE
        binding.txtStatus.text = ""
        binding.txtQualityLabel.text = "Qualität: ${qualityFromProgress(binding.seekQuality.progress)}%"
    }

    private fun getFileName(uri: Uri): String {
        var name = "PDF"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    private fun getFileSize(uri: Uri): Long {
        var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (idx >= 0 && cursor.moveToFirst()) size = cursor.getLong(idx)
        }
        return size
    }

    private fun formatSize(bytes: Long): String {
        return if (bytes > 1024 * 1024) {
            "%.1f MB".format(bytes / (1024.0 * 1024.0))
        } else {
            "${(bytes / 1024.0).roundToInt()} KB"
        }
    }

    private fun runCompression() {
        val uri = pickedUri ?: return
        binding.btnRunCompress.isEnabled = false
        binding.txtStatus.text = "Komprimiere..."
        binding.txtResult.visibility = android.view.View.GONE
        binding.btnSaveCompressed.visibility = android.view.View.GONE

        Thread {
            try {
                val quality = qualityFromProgress(binding.seekQuality.progress)
                val fd: ParcelFileDescriptor = contentResolver.openFileDescriptor(uri, "r")
                    ?: throw Exception("Datei konnte nicht geöffnet werden")
                val renderer = PdfRenderer(fd)
                val document = PdfDocument()

                for (i in 0 until renderer.pageCount) {
                    runOnUiThread { binding.txtStatus.text = "Verarbeite Seite ${i + 1} von ${renderer.pageCount}..." }

                    val page = renderer.openPage(i)
                    // scale 1.5 statt 2 spart zusätzlich Größe bei kaum sichtbarem Unterschied
                    val scale = 1.5f
                    val bmp = Bitmap.createBitmap(
                        (page.width * scale).toInt(),
                        (page.height * scale).toInt(),
                        Bitmap.Config.ARGB_8888
                    )
                    val canvas = Canvas(bmp)
                    canvas.drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()

                    // JPEG-Kompression anwenden
                    val jpegStream = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, quality, jpegStream)
                    val jpegBytes = jpegStream.toByteArray()
                    val compressedBmp = android.graphics.BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)

                    val assumedDpi = 108f // entspricht scale 1.5 (1.5 * 72)
                    val (pageWidthPt, pageHeightPt) = pixelsToPdfPoints(compressedBmp.width, compressedBmp.height, assumedDpi)

                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPt.toInt(), pageHeightPt.toInt(), i + 1).create()
                    val pdfPage = document.startPage(pageInfo)
                    val destRect = android.graphics.RectF(0f, 0f, pageWidthPt, pageHeightPt)
                    pdfPage.canvas.drawBitmap(compressedBmp, null, destRect, null)
                    document.finishPage(pdfPage)

                    bmp.recycle()
                    compressedBmp.recycle()
                }
                renderer.close()
                fd.close()

                val outStream = ByteArrayOutputStream()
                document.writeTo(outStream)
                document.close()
                compressedBytes = outStream.toByteArray()

                val newSize = compressedBytes!!.size.toLong()
                val savedPercent = if (originalSizeBytes > 0)
                    ((1 - newSize.toDouble() / originalSizeBytes) * 100).roundToInt()
                else 0

                runOnUiThread {
                    binding.txtStatus.text = ""
                    binding.txtResult.text = if (savedPercent > 0)
                        "Fertig: ${formatSize(originalSizeBytes)} → ${formatSize(newSize)} ($savedPercent% kleiner)"
                    else
                        "Fertig: ${formatSize(originalSizeBytes)} → ${formatSize(newSize)}"
                    binding.txtResult.visibility = android.view.View.VISIBLE
                    binding.btnSaveCompressed.visibility = android.view.View.VISIBLE
                    binding.btnRunCompress.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.txtStatus.text = "Fehler: ${e.message}"
                    binding.btnRunCompress.isEnabled = true
                }
            }
        }.start()
    }

    private fun saveCompressed() {
        val bytes = compressedBytes ?: return
        val baseName = originalFileName.removeSuffix(".pdf").removeSuffix(".PDF")
        val fileName = "${baseName}_komprimiert.pdf"

        try {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BilderZuPDF")
                }
                val resultUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                resultUri?.let { contentResolver.openOutputStream(it)?.use { out -> out.write(bytes) } }
                resultUri
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val appDir = File(downloadsDir, "BilderZuPDF")
                if (!appDir.exists()) appDir.mkdirs()
                val outFile = File(appDir, fileName)
                outFile.writeBytes(bytes)
                Uri.fromFile(outFile)
            }

            if (uri != null) {
                Toast.makeText(this, "Gespeichert in Downloads: $fileName", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Fehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
