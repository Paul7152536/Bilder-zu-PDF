package com.goerner.bilderzupdf

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.goerner.bilderzupdf.databinding.ActivityPdfMergeBinding
import java.io.File
import java.io.FileOutputStream

class PdfMergeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfMergeBinding
    private val pages = mutableListOf<MergePage>()
    private lateinit var adapter: MergePageAdapter
    private var counter = 0
    private var editingPosition: Int = -1

    private val pickPdfsLauncher =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) {
                loadPdfPages(uris)
            }
        }

    private val editPageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val path = result.data?.getStringExtra(ImageEditActivity.EXTRA_RESULT_PATH)
            if (result.resultCode == RESULT_OK && path != null && editingPosition >= 0) {
                val editedBitmap = android.graphics.BitmapFactory.decodeFile(path)
                if (editedBitmap != null) {
                    val old = pages[editingPosition]
                    pages[editingPosition] = old.copy(bitmap = editedBitmap)
                    adapter.notifyItemChanged(editingPosition)
                }
            }
            editingPosition = -1
        }

    private val previewLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfMergeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = MergePageAdapter(
            pages,
            onRemove = { pos -> pages.removeAt(pos); adapter.notifyItemRemoved(pos) },
            onEdit = { pos -> openEditor(pos) }
        )
        binding.recyclerPages.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerPages.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                adapter.moveItem(vh.bindingAdapterPosition, target.bindingAdapterPosition)
                return true
            }
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.recyclerPages)

        binding.btnAddPdfs.setOnClickListener {
            pickPdfsLauncher.launch("application/pdf")
        }

        binding.btnMerge.setOnClickListener {
            openPreview()
        }
    }

    private fun openEditor(position: Int) {
        editingPosition = position
        val bmp = pages[position].bitmap
        val tempFile = File(cacheDir, "merge_edit_${System.currentTimeMillis()}.png")
        FileOutputStream(tempFile).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }

        val intent = android.content.Intent(this, ImageEditActivity::class.java)
        intent.putExtra(ImageEditActivity.EXTRA_IMAGE_URI, Uri.fromFile(tempFile).toString())
        editPageLauncher.launch(intent)
    }

    private fun loadPdfPages(uris: List<Uri>) {
        Toast.makeText(this, "Lade PDFs...", Toast.LENGTH_SHORT).show()
        for (uri in uris) {
            try {
                val fd: ParcelFileDescriptor = contentResolver.openFileDescriptor(uri, "r") ?: continue
                val renderer = PdfRenderer(fd)
                val displayName = getFileName(uri)

                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    val bmp = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bmp)
                    canvas.drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()

                    pages.add(MergePage(counter++, bmp, 0, "$displayName · Seite ${i + 1}"))
                }
                renderer.close()
                fd.close()
            } catch (e: Exception) {
                Toast.makeText(this, "Fehler beim Laden einer PDF: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        adapter.notifyDataSetChanged()
    }

    private fun getFileName(uri: Uri): String {
        var name = "PDF"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }

    private fun openPreview() {
        if (pages.isEmpty()) {
            Toast.makeText(this, "Bitte zuerst PDFs hinzufügen", Toast.LENGTH_SHORT).show()
            return
        }
        PagesHolder.pages = pages
        previewLauncher.launch(android.content.Intent(this, PdfPreviewActivity::class.java))
    }
}
