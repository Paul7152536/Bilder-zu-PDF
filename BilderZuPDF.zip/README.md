# Bilder zu PDF

Android-App: Bilder zu PDF wandeln, Texte in Bildern/PDFs bearbeiten, mehrere PDFs zusammenführen.

## Funktionen
- Mehrere Bilder auswählen, Reihenfolge per Ziehen ändern, PDF erstellen (landet direkt in Downloads/BilderZuPDF)
- "Text bearbeiten" pro Bild: automatische Texterkennung (offline, ML Kit), Text ändern oder neuen Text hinzufügen
- "PDF bearbeiten (beliebige Datei)": jede vorhandene PDF öffnen, Text pro Seite ändern/hinzufügen, neu speichern
- "PDFs zusammenführen": mehrere PDFs laden, Seiten per Ziehen sortieren, einzeln drehen, zu einer PDF zusammenführen
- "Meine PDFs": Übersicht aller erstellten PDFs, öffnen/teilen/löschen

## Build
Läuft automatisch über GitHub Actions bei jedem Push auf `main`. Fertige APK erscheint unter "Releases" im Repo.

Wichtig: Die `BilderZuPDF.zip` wird von GitHub Actions selbst entpackt (siehe `.github/workflows/build.yml`) -
du musst sie beim Hochladen ins Repo NICHT selbst entpacken, einfach als Datei ins Repo-Root hochladen.
