# Bilder zu PDF

Android-App zum Umwandeln mehrerer Bilder in eine PDF-Datei.

## Funktionen
- Mehrere Bilder aus der Galerie auswählen
- Reihenfolge der Bilder per Ziehen ändern (Drag & Drop)
- PDF erstellen (jedes Bild = eine Seite, automatische Rotation nach EXIF)
- Mehrere erstellte PDFs verwalten (Übersicht, öffnen, teilen, löschen)

## Build

Der Build läuft automatisch über GitHub Actions (`.github/workflows/build.yml`) bei jedem Push auf `main`.
Die fertige APK findest du danach als Artifact "BilderZuPDF-debug" im jeweiligen Actions-Lauf auf GitHub.

Alternativ lokal in Android Studio: Projekt öffnen -> Build -> Build APK(s).

## Nächste Schritte
1. Repo auf GitHub anlegen und diesen Ordner hochladen (bzw. Inhalt pushen)
2. Unter "Actions" den Workflow "Build APK" laufen lassen (bei Push automatisch, oder manuell über "Run workflow")
3. APK aus dem Artifact herunterladen und auf dem Handy installieren (Unbekannte Quellen erlauben)
